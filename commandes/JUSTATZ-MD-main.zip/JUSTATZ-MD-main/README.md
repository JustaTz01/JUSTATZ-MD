</h1> 
<p align="center">JUSTATZ MD V1

<p align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=900&size=30&duration=4000&pause=1000&random=false&width=435&lines=+JUSTATZ+WHATSAPP+BOT+TZ1ATED+BY+JUSTATZ+BOY+SON+Fork+Me+Please" alt="Typing SVG" /></a>
 </p>
 
 <a href="https://wa.me/message/J2ZL2GNK4GIUA1">
 <img alt="JUSTATZ 𝕄𝔻" height="300" src="https://telegra.ph/file/347ba7a613b4d025b89a8.jpg".

</h1> 
<p align="center">ɪ ɪɴᴛʀᴏᴅᴜᴄᴇ <b>𝕃
TIMNASA MD</b>, simple powerful bot </p>

</p>
  <p align="center">
<a href="https://github.com/JustaTz01?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/JustaTz01?label=Followers&style=social"></a>
<a href="https://github.com/JustaTz01/JUSTATZ-MD/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/JustaTz01/JUSTATZ-MD?&style=social"></a>
<a href="https://github.com/JustaTz01/JUSTATZ-MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/JustaTz01/JUSTATZ-MD?style=social"></a>
<a href="https://github.com/JustaTz01/JUSTATZ-MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/JustaTz01/JUSTATZ-MD?label=Watching&style=social"></a>

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{HANSTZ3}/count.svg" alt="JUSTATZ-MD :: Visitor's Count"/></p>

</a>
  <div align="center">
  <img src="https://spogit.vercel.app/api?theme=dark&black=true&scan=true" alt="Widget with the current Spotify song"  />
</div>

---

<p align="center">
  <a href="https://github.com/hanstz3/hans_md"><b>JUSTATZ 𝕄𝔻</b></a> 𝙎𝙪𝙥𝙥𝙤𝙧𝙩 𝘿𝙚𝙥𝙡𝙤𝙮 𝙊𝙣...
</p>

<p align="center">
  <a href="https://youtu.be/Pj6DV2HouH4?si=TTarJ04UWxzSAdMU"><img src="https://img.shields.io/badge/CodeSpace-green?colorA=%23ff000&colorB=%23017e40&style=for-the-badge&logo=git&logoColor=white"></a>
</p>




## ℍ𝕆𝕎 𝕋𝕆 𝔻𝔼ℙ𝕃𝕆𝕐 JUSTATZ 𝕄𝔻 


## 𝟙.𝔽𝕀ℝ𝕊𝕋 𝕊𝕋𝔼ℙ 
FORK this repo JUSTATZ-MD


<a href="https://github.com/JustaTz01/JUSTATZ-MD/fork"><img title="Tap Here Open Session Site" src="https://img.shields.io/badge/𝔽𝕆ℝ𝕂 𝕋ℍ𝕀𝕊 ℝ𝔼ℙ𝕆-h?color=black&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

sᴛᴀʀ 🌟 ᴍʏ ʀᴇᴘᴏ ɪғ ʏᴏᴜ ʟɪᴋᴇ ᴛʜɪs ʙᴏᴛ ®️

## 𝟚.𝕊𝔼ℂ𝕆ℕ𝔻 𝕊𝕋𝔼ℙ 


 𝔾𝔼𝕋 𝕊𝔼𝕊𝕊𝕀𝕆ℕ 𝕀𝔻 𝔹𝕐
 

<a href="https://hanscoder-d74ac23a6e00.herokuapp.com/wasiqr"><img title="Tap Here Open Session Site" src="https://img.shields.io/badge/ℚℝ ℂ𝕆𝔻𝔼-h?color=black&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>


 
<a href="https://justaaganicoder-b959e1c1d915.herokuapp.com"><img title="Tap Here Open Session Site" src="https://img.shields.io/badge/𝕊𝕀𝕋𝔼 𝔽𝕆ℝ ℙ𝔸𝕀ℝ-h?color=black&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>


## 𝟛.𝕋ℍ𝕀ℝ𝔻 𝕊𝕋𝔼ℙ 
**1. ɪғ ʏᴏᴜ ᴅᴏɴ'ᴛ ʜᴀᴠᴇ ᴀᴄᴄᴏᴜɴᴛ ᴏɴ ʜᴇʀᴏᴋᴜ**

<a href="https://signup.heroku.com">
 <img src="https://img.shields.io/badge/ℂℝ𝔼𝔸𝕋𝔼%20𝔸ℂℂ𝕆𝕌ℕ𝕋%20ℕ𝕆𝕎-purple?style=for-the-badge&logo=heroku" width="200" height="38.45"/></a></p>

**2. ɪғ ʏᴏᴜ ʜᴀᴠᴇ ᴀᴄᴄᴏᴜɴᴛ ᴏɴ ʜᴇʀᴏᴋᴜ**       
<br>
<a href="https://dashboard.heroku.com/new?template=https://github.com/JustaTz01/JUSTATZ-MD/tree/main">
 <img src="https://img.shields.io/badge/𝔻𝔼ℙ𝕃𝕆𝕐%20𝕋𝕆%20ℍ𝔼ℝ𝕆𝕂𝕌-purple?style=for-the-badge&logo=heroku" width="200" height="38.45"/></a></p>


##




ℂ𝕆ℕ𝕋𝔸ℂ𝕋 𝔻𝔼𝕍𝔼𝕃𝕆ℙ𝔼ℝ 𝕆ℕ 𝕎ℍ𝔸𝕋𝕊𝔸ℙℙ 

𝕎𝔸𝕋𝕊𝔸ℙℙ 𝕄𝔼
<a href="https://wa.me/message/J2ZL2GNK4GIUA1"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/whatsapp.svg" alt="255784554031" height="60" width="70" /></a>


𝕎𝔸𝕋𝕊𝔸ℙℙ ℂℍ𝔸ℕℕ𝔼𝕃
<a
href="https://youtube.com/@justatz?si=tqLJPjHj_7WIH26pyoutubechannel/0029VajweHxKQuJP6qnjLM31"  target="blank"><img
 align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/whatsapp.svg" alt="hanstech" height="60" width="70" /></a>


## License

The WhatsApp Bot JUSTATZ MD is released under the [MIT License](https://opensource.org/licenses/MIT).


🌟 𝕋ℍ𝔸ℕ𝕂 𝕐𝕆𝕌 𝔽𝕆ℝ ℂℍ𝕆𝕆𝕊𝕀ℕ𝔾 JUSTATZ🍀_MD 🌟


## 𝔻𝔼𝕍𝔼𝕃𝕆ℙ𝔼ℝ𝕊 :

- [**JUSTATZ TECH**](https://github.com/)
- [**JUSTATZ TECH**](https://github.com/JustaTz01)
     


